import 'package:flutter/material.dart';
import 'hal_utama.dart';


void main() {
  runApp(new MaterialApp(
    title: "Hallovent!",
    home: new HalUtama(),
  ));
}
